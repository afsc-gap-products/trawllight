### R code from vignette source 'intro.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: intro.Rnw:66-67 (eval = FALSE)
###################################################
## vignette(package = "kedd")


###################################################
### code chunk number 2: intro.Rnw:70-71 (eval = FALSE)
###################################################
## demo(package = "kedd")


###################################################
### code chunk number 3: intro.Rnw:86-87 (eval = FALSE)
###################################################
## citation()


###################################################
### code chunk number 4: intro.Rnw:90-91 (eval = FALSE)
###################################################
## citation("kedd")


